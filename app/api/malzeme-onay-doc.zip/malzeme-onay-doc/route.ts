// app/api/malzeme-onay-doc/route.ts
import { NextResponse } from 'next/server';
import ExcelJS from 'exceljs';
import path from 'path';
import fs from 'fs';

export async function POST(request: Request) {
  try {
    const { materials } = await request.json();

    if (!materials || materials.length === 0) {
      return NextResponse.json({ error: 'Filtrelenmiş malzeme bulunamadı.' }, { status: 400 });
    }

    const templatePath = path.join(process.cwd(), 'public', 'sablon.xlsx');
    
    if (!fs.existsSync(templatePath)) {
      return NextResponse.json({ error: 'sablon.xlsx dosyası public klasöründe bulunamadı!' }, { status: 404 });
    }

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(templatePath);
    const worksheet = workbook.worksheets[0]; 

    // 1. KUSURSUZ GRUPLAMA ALGORİTMASI (YENİ PRISMA YAPISINA TAM UYUMLU)
    const groupedData: any[] = [];
    let totalDataRows = 0;

    materials.forEach((item: any) => {
      // YENİ YAPI (Markalar ve Standartlar dizileri içeriyorsa)
      if (item.markalar && Array.isArray(item.markalar)) {
        let cName = (item.name || '-').trim();
        cName = cName.replace(/-/g, '\u2011').replace(/ \(/g, '\u00A0('); 
        
        let cinsGroup = groupedData.find((g: any) => g.cins === cName);
        if (!cinsGroup) {
          cinsGroup = { cins: cName, companies: [], totalRows: 0 };
          groupedData.push(cinsGroup);
        }

        item.markalar.forEach((marka: any) => {
           let mName = (marka.name || '-').trim();
           let companyGroup = cinsGroup.companies.find((c: any) => c.marka === mName);
           if (!companyGroup) {
             companyGroup = { marka: mName, certs: [] };
             cinsGroup.companies.push(companyGroup);
           }

           let certs = marka.standartlar || [];
           if (certs.length === 0) certs = [{}];

           certs.forEach((cert: any) => {
             companyGroup.certs.push({
               standart: cert.standart_adi || cert.standart || '-',
               belge_no: cert.belge_no || '-',
               expiry_date: cert.gecerlilik || cert.expiry_date || '-'
             });
             cinsGroup.totalRows += 1; 
             totalDataRows += 1; 
           });
        });
      } 
      // ESKİ YAPI (Geriye Dönük Uyumluluk İçin)
      else {
        let cName = (item.cins_name || '-').trim();
        cName = cName.replace(/-/g, '\u2011').replace(/ \(/g, '\u00A0('); 
        const mName = (item.company_name || '-').trim();

        let cinsGroup = groupedData.find((g: any) => g.cins === cName);
        if (!cinsGroup) {
          cinsGroup = { cins: cName, companies: [], totalRows: 0 };
          groupedData.push(cinsGroup);
        }

        let companyGroup = cinsGroup.companies.find((c: any) => c.marka === mName);
        if (!companyGroup) {
          companyGroup = { marka: mName, certs: [] };
          cinsGroup.companies.push(companyGroup);
        }

        let certs: any[] = [];
        try { certs = JSON.parse(item.certificates || '[]'); } catch(e) { certs = [{}]; }
        if (certs.length === 0) certs = [{}];

        certs.forEach((cert: any) => {
          companyGroup.certs.push({
            standart: cert.standart || '-',
            belge_no: cert.belge_no || '-',
            expiry_date: cert.expiry_date || '-'
          });
          cinsGroup.totalRows += 1; 
          totalDataRows += 1; 
        });
      }
    });

    // 2. KUSURSUZ SATIR ENJEKSİYONU (BOŞLUK VE MERGE SORUNLARINI ÇÖZER)
    // Şablondaki 15. satırı zaten 1. veri satırı olarak kullanacağımız için (N - 1) kadar satır ekliyoruz.
    // Eklemeyi 15'ten değil 16'dan yapıyoruz ki şablondaki o boş 15. satır aşağıya itilip Footer'da hayalet boşluk yaratmasın!
    const rowsToInsert = totalDataRows > 1 ? totalDataRows - 1 : 0;
    if (rowsToInsert > 0) {
      worksheet.spliceRows(16, 0, ...Array(rowsToInsert).fill([]));
    }
    // NOT: Footer birleştirmeleri (merges) otomatik olarak ve HİÇ BOZULMADAN aşağı kaydı.

    // 3. VERİ YAZMA VE DİNAMİK HÜCRE BOYAMA (Tablo İçi)
    let currentRow = 15; 
    let siraNo = 1;
    const mergesToExecute: string[] = []; 
    const masterCellsToFix: any[] = []; 

    groupedData.forEach((cinsGroup) => {
      const cinsStartRow = currentRow;
      const cinsEndRow = cinsStartRow + cinsGroup.totalRows - 1;

      cinsGroup.companies.forEach((compGroup: any) => {
        const compStartRow = currentRow;
        const compEndRow = compStartRow + compGroup.certs.length - 1;

        compGroup.certs.forEach((cert: any) => {
          const row = worksheet.getRow(currentRow);
          row.height = 35; // Tüm veri satırlarını ideal yükseklikte sabitler

          row.getCell('C').value = currentRow === cinsStartRow ? siraNo : null;
          row.getCell('D').value = currentRow === cinsStartRow ? cinsGroup.cins : null;
          row.getCell('E').value = currentRow === compStartRow ? compGroup.marka : null;

          row.getCell('F').value = cert.standart;
          row.getCell('G').value = cert.belge_no;
          row.getCell('H').value = cert.expiry_date;

          const isFirstRowOfTable = currentRow === 15;
          const isLastRowOfCins = currentRow === cinsEndRow;

          ['C', 'D', 'E', 'F', 'G', 'H'].forEach(col => {
            const cell = row.getCell(col);
            
            cell.border = {
              top: { style: isFirstRowOfTable ? 'medium' : 'thin', color: { argb: 'FF000000' } },
              bottom: { style: isLastRowOfCins ? 'medium' : 'thin', color: { argb: 'FF000000' } },
              left: { style: col === 'C' ? 'medium' : 'thin', color: { argb: 'FF000000' } },
              right: { style: col === 'H' ? 'medium' : 'thin', color: { argb: 'FF000000' } }
            };

            cell.font = { name: 'Arial', size: 11, bold: (col === 'C' || col === 'D') };
            cell.alignment = { 
              vertical: 'middle', 
              horizontal: ['C', 'D', 'F', 'G', 'H'].includes(col) ? 'center' : 'left', 
              wrapText: true 
            };
          });

          currentRow++;
        });

        if (compEndRow > compStartRow) {
          mergesToExecute.push(`E${compStartRow}:E${compEndRow}`);
        }
        masterCellsToFix.push({ address: `E${compStartRow}`, isFirstTable: compStartRow === 15, isLastCins: compEndRow === cinsEndRow, col: 'E' });
      });

      if (cinsEndRow > cinsStartRow) {
        mergesToExecute.push(`C${cinsStartRow}:C${cinsEndRow}`);
        mergesToExecute.push(`D${cinsStartRow}:D${cinsEndRow}`);
      }
      
      masterCellsToFix.push({ address: `C${cinsStartRow}`, isFirstTable: cinsStartRow === 15, isLastCins: true, col: 'C' });
      masterCellsToFix.push({ address: `D${cinsStartRow}`, isFirstTable: cinsStartRow === 15, isLastCins: true, col: 'D' });

      siraNo++; 
    });

    // 4. VERİ TABLOSU BİRLEŞTİRMELERİNİ ATEŞLE
    mergesToExecute.forEach(range => {
      try { worksheet.mergeCells(range); } catch (e) { console.warn(`Merge engeli: ${range}`); }
    });

    // 5. MASTER HÜCRELERİ MÜHÜRLE (Birleşen hücrelerin kenarlık kaybını önler)
    masterCellsToFix.forEach(info => {
      const cell = worksheet.getCell(info.address);
      cell.border = {
        top: { style: info.isFirstTable ? 'medium' : 'thin', color: { argb: 'FF000000' } },
        bottom: { style: info.isLastCins ? 'medium' : 'thin', color: { argb: 'FF000000' } },
        left: { style: info.col === 'C' ? 'medium' : 'thin', color: { argb: 'FF000000' } },
        right: { style: 'thin', color: { argb: 'FF000000' } }
      };
    });

    // 6. TABLONUN DIŞ ANA KENARLIKLARINI GÜÇLENDİR (Sol 'C' ve Sağ 'H')
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber >= 15 && rowNumber <= 15 + totalDataRows - 1) {
        const cellC = row.getCell('C');
        cellC.border = { ...(cellC.border || {}), left: { style: 'medium', color: { argb: 'FF000000' } } };

        const cellH = row.getCell('H');
        cellH.border = { ...(cellH.border || {}), right: { style: 'medium', color: { argb: 'FF000000' } } };
      }
    });

    // 7. FORMÜL KORUMASI VE OTOMATİK TARİH GÜNCELLEMESİ (Tüm Sayfa İçin)
    workbook.calcProperties.fullCalcOnLoad = true;
    
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    const formattedDateString = `___${dd}__ / __${mm}__ / ${yyyy}`;

    const dateRegex = /___\d{2}__\s*\/\s*__\d{2}__\s*\/\s*\d{4}/g;

    worksheet.eachRow((row) => {
      row.eachCell((cell) => {
        if (typeof cell.value === 'string') {
          if (dateRegex.test(cell.value)) {
            cell.value = cell.value.replace(dateRegex, formattedDateString);
          }
        } 
        else if (cell.value && typeof cell.value === 'object' && 'richText' in cell.value) {
          let hasChange = false;
          const newRichText = (cell.value as any).richText.map((rt: any) => {
            if (dateRegex.test(rt.text)) {
              hasChange = true;
              return { ...rt, text: rt.text.replace(dateRegex, formattedDateString) };
            }
            return rt;
          });
          if (hasChange) {
            cell.value = { richText: newRichText };
          }
        }
        else if (cell.value && typeof cell.value === 'object' && ('formula' in cell.value || 'sharedFormula' in cell.value)) {
          const formulaStr = String((cell.value as any).formula || '').toUpperCase();
          const resultValue = (cell.value as any).result;

          if (/^[A-Z]{1,2}\d{1,3}$/.test(formulaStr) || formulaStr.includes('19') || resultValue === 0) {
            cell.value = formattedDateString;
          } else {
            const formulaValue = cell.value as any;
            cell.value = {
              formula: formulaValue.formula,
              sharedFormula: formulaValue.sharedFormula
            };
          }
        }
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();

    return new Response(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename=Malzeme_Oneri_ve_Onay_Formu.xlsx`,
      },
    });

  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}